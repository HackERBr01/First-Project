const increment = document.querySelector(".increment");
const counter = document.querySelector(".counter");

increment.addEventListener("click", () => {
    counter.innerHTML++;
}) 